package com.example.checkuser;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    private TextView vencimentoDate;
    private TextView diasRestantes;
    private TextView avisos;
    private TextView usuario;
    private EditText current_username;
    private EditText serverURL;
    private Button startCheck;
    private EditText currentURLContato;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final SharedPreferences prefs = PreferenceManager
                .getDefaultSharedPreferences(this);

        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        diasRestantes = (TextView) findViewById(R.id.txtDiasRestantes);
        vencimentoDate = (TextView) findViewById(R.id.txtVencimentoDate) ;
        avisos= (TextView) findViewById(R.id.txtAvisos) ;
        usuario = (TextView) findViewById(R.id.txtUser) ;

        currentURLContato = (EditText) findViewById(R.id.currentURLContato) ;
        currentURLContato.setText(prefs.getString("currentURLContato", ""));

        current_username = (EditText) findViewById(R.id.currentUsername) ; //PEGA O NOME DE USUARIO DO EDITEXT
        current_username.setText(prefs.getString("currentUsernamePref", ""));

        serverURL = (EditText) findViewById(R.id.currentURLServer) ; //PEGA A URL DO PAINEL DO EDITEXT
        serverURL.setText(prefs.getString("serverURLPref", ""));

        startCheck = (Button) findViewById(R.id.startCheck) ; //BOTAO DE INICIAR A CHECAGEM,ELE CHAMA A VOID CHECKUSER();
        startCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             if (current_username.getText().toString().equals("") || serverURL.getText().toString().equals("")){
                 vencimentoDate.setVisibility(View.GONE);
                 usuario.setVisibility(View.GONE);
                 diasRestantes.setVisibility(View.GONE);
                 avisos.setText("Nome de usuário ou URL vazios!");
             }else{
                 prefs.edit().putString("currentUsernamePref", current_username.getText().toString()).commit();
                 prefs.edit().putString("serverURLPref", serverURL.getText().toString()).commit();
                 prefs.edit().putString("currentURLContato", currentURLContato.getText().toString()).commit();
                 checkUser();
                 v.vibrate(500);

             }
            }
        });


       // checkUser();//COLOQUE NO ONCREATE DO APP,E COLOQUE DENTRO DO SSH_CONECTADO PRA FAZER A REQUEST QUANDO CONECTADO A VPN
    }

    private void checkUser() {
        //final SharedPreferences prefs= mConfig.getPrefsPrivate();
        //String current_user = prefs.getString(Settings.USUARIO_KEY, ""); //AQUI É ONDE PEGA O USUÁRIO USADO
        String current_user = current_username.getText().toString();

        String URLServer =  serverURL.getText().toString();//AQUI É ONDE PEGA A URL DO SERVIDOR DO BANCO DE DADOS/PAINEL
        usuario.setVisibility(View.VISIBLE);
        usuario.setText("Usuário:" + current_user);
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL(URLServer);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
                    conn.setRequestProperty("Accept","application/json");
                    conn.setDoOutput(true);
                    conn.setDoInput(true);

                    JSONObject jsonParam = new JSONObject();
                    jsonParam.put("user", current_user);

                    Log.i("JSON", jsonParam.toString());

                    DataOutputStream os = new DataOutputStream(conn.getOutputStream());
                    //os.writeBytes(URLEncoder.encode(jsonParam.toString(), "UTF-8"));
                    os.writeBytes(jsonParam.toString());
                    os.flush();
                    os.close();

                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                            String result;

                            while ((result = bufferedReader.readLine()) != null) {
                                String resultFinal = result.replace("\"", "");
                                if (resultFinal.equals("not exist")){
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            vencimentoDate.setVisibility(View.GONE);
                                            usuario.setVisibility(View.GONE);
                                            diasRestantes.setVisibility(View.GONE);
                                            avisos.setVisibility(View.VISIBLE);
                                            avisos.setText("Usuário não encontrado no banco de dados!");
                                            avisos.setTextColor(Color.RED);
                                        }
                                    });

                                }else{
                                    showUserInfo(resultFinal);
                                }
                                Log.d("JSON",resultFinal);

                            }
                        }
                    }else {
                        vencimentoDate.setVisibility(View.GONE);
                        usuario.setVisibility(View.GONE);
                        diasRestantes.setVisibility(View.GONE);
                        avisos.setVisibility(View.VISIBLE);
                        avisos.setText("Ocorreu um erro ao obter as informações do login :(");
                        avisos.setTextColor(Color.RED);
                        //ERRO NA CHECAGEM
                        // SkStatus.logInfo("Erro ao obter informações do usuários");
                    }

                    conn.disconnect();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        thread.start();
    }

    private void showUserInfo(String result) {
        //MOSTRA DATA E FAZ CHECAGEM
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date hoje = new Date();
        String CurrentDate = dateFormat.format(hoje);

        runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    //FORMATA DATA
                    String data = formatDate(result);
                    //SETA DATA DE VENCIMENTO FORMATADA NO TEXTVIEW
                    vencimentoDate.setVisibility(View.VISIBLE);
                    vencimentoDate.setText("Vencimento: "+data);

                    //VERIFICA DIAS RESTANTES
                   try {
                       Date firstDate = sdf.parse(CurrentDate);
                       Date secondDate = sdf.parse(data);

                       long diff = secondDate.getTime() - firstDate.getTime();
                       TimeUnit time = TimeUnit.DAYS;
                       long dias_diferenca = time.convert(diff, TimeUnit.MILLISECONDS);
                       int dias_diferenca_int = (int) dias_diferenca;

                       diasRestantes.setVisibility(View.VISIBLE);
                       diasRestantes.setText("Dias restantes: " + dias_diferenca_int);

                       avisos.setVisibility(View.VISIBLE);
                       if (dias_diferenca_int <= 3){
                           avisos.setText("Atenção!Restam "+ dias_diferenca_int + " dias para o vencimento do seu login! CLIQUE AQUI E CONTATE O SUPORTE");
                           avisos.setTextColor(Color.RED);

                           avisos.setOnClickListener(new View.OnClickListener() {

                               @Override
                               public void onClick(View v) {
                                   String url = "";
                                   if (currentURLContato.getText().toString().isEmpty()){
                                       url = "https://t.me/andley302";
                                   }else{
                                       url = currentURLContato.getText().toString();
                                   }
                                   Intent intentsuporte = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                                   intentsuporte.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                   startActivity(Intent.createChooser(intentsuporte, "Abrir com"));
                               }
                           });
                       }else{
                           avisos.setText("Olá,seu login está OK.Bom uso!");
                           avisos.setTextColor(Color.BLUE);

                       }

                   } catch (Exception e) {
                       e.printStackTrace();
                   }

                }
            });




    }

    public static String formatDate(String data){
        String dateStr = data;
        String returnString = "";
        try{
            SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
            Date date = sdf.parse(dateStr);
            sdf = new SimpleDateFormat("dd/MM/yyyy");
            dateStr = sdf.format(date);
            returnString = dateStr;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return returnString;
    }

}